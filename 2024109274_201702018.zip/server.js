import express from "express";
import favicon from "serve-favicon";
import path from "path";
import { fileURLToPath } from "url";
import orchidsRouter from "./routes/orchids.js";
import initDatabase from "./api/config/init-db.js";

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("www", { index: "index.html" }));
app.use(favicon(path.join(path.dirname(fileURLToPath(import.meta.url)), "/www/images/favicon.ico")));

// CORS middleware
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  next();
});

// Routes

app.use("/api/orchids", orchidsRouter);

app.get("/api", (req, res) => {
  res.json({ message: "Orquideas Pro API" });
});

// Start server
app.listen(PORT, async () => {
  console.log(`Server is running on http://localhost:${PORT}`);
  console.log("Initializing database...");
  await initDatabase();
});
